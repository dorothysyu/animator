package cs3500.animator.model;

import java.util.ArrayList;
import java.util.List;

import util.TweenModelBuilder;

/**
 * This is the implementation for AnimatorModel.
 */
public final class AnimatorModelImpl implements AnimatorModel {

  // The entire list of IShapes that this model contains.
  private List<IShape> shapes;

  // Constructor that takes in a builder.
  private AnimatorModelImpl(Builder builder) {
    this.shapes = builder.builderShapes;
  }

  /**
   * This sets this entire animation's tempo. Each time field in each shape is modified
   * according to the given ticksPerSecond.
   */
  public void setTempo(int ticksPerSecond) {
    for (IShape s : shapes) {
      s.setTempo(ticksPerSecond);
    }
  }

  /**
   * This returns all the shapes at the given frameCount, essentially returning a frozen
   * frame of the animation at the given time.
   *
   * @param frameCount the time at which the shapes will be
   * @return a list of shapes representing a frozen frame.
   */
  public List<IShape> getShapesAtFrame(double frameCount) {
    if (frameCount < 0) {
      throw new IllegalArgumentException("Can't have a negative frame count!");
    }
    List<IShape> shapes = new ArrayList<>();
    for (IShape shape : this.shapes) {
      if (frameCount >= shape.getAppearAt()) {
        shapes.add(shape.getStateAt(frameCount));
      }
    }
    return shapes;
  }

  /**
   * Looks through the entire list of shapes' disappear times and
   * returns the largest disappear time.
   *
   * @return double representing when the last shape is on the screen
   */
  public double getMaxDisappearTime() {
    double max = 0;
    for (IShape shape : shapes) {
      max = Math.max(shape.getDisappearAt(), max);
    }
    return max;
  }

  /**
   * Returns a textual representation of this entire animation, with shape descriptions
   * and each shape's transformations.
   */
  public String printAsString() {
    String description = "Shapes:\n";
    for (IShape s : shapes) {
      description += s.printShapeDescription();
    }
    description += "\n";
    for (IShape s : shapes) {
      description += s.commandsToStrings();
    }
    return description;
  }

  /**
   * Returns a textual representation of the entire animation in SVG format.
   */
  public String printSVGDescription() {
    String descr = "<svg width=\"1000\" height=\"1000\" version=\"1.1\"\n"
            + "     xmlns=\"http://www.w3.org/2000/svg\">\n";
    for (IShape shape : shapes) {
      descr += shape.printSVGShape();
    }
    descr += "\n</svg>";
    return descr;
  }

  /**
   * This is a builder class that ultimately adds shapes to the model and transformations to the
   * shapes in the model.
   */
  public static final class Builder implements TweenModelBuilder<AnimatorModel> {

    private List<IShape> builderShapes;

    public Builder() {
      this.builderShapes = new ArrayList<>();
    }

    /**
     * This adds an oval to the list of shapes.
     *
     * @param name        the unique name given to this shape
     * @param cx          the x-coordinate of the center of the oval
     * @param cy          the y-coordinate of the center of the oval
     * @param xRadius     the x-radius of the oval
     * @param yRadius     the y-radius of the oval
     * @param red         the red component of the color of the oval
     * @param green       the green component of the color of the oval
     * @param blue        the blue component of the color of the oval
     * @param startOfLife the time tick at which this oval appears
     * @param endOfLife   the time tick at which this oval disappears
     * @return this builder with the oval added to its list of shapes.
     */
    @Override
    public TweenModelBuilder<AnimatorModel> addOval(String name, float cx, float cy,
                                                    float xRadius, float yRadius, float red,
                                                    float green, float blue, int startOfLife,
                                                    int endOfLife) {
      Oval o = new Oval(name, cx, cy, xRadius, yRadius, startOfLife, endOfLife,
              red, green, blue, new ArrayList<>());
      builderShapes.add(o);
      return this;
    }

    /**
     * This adds a rectangle to the list of shapes.
     *
     * @param name        the unique name given to this shape
     * @param lx          the minimum x-coordinate of a corner of the
     *                    rectangle
     * @param ly          the minimum y-coordinate of a corner of the
     *                    rectangle
     * @param width       the width of the rectangle
     * @param height      the height of the rectangle
     * @param red         the red component of the color of the rectangle
     * @param green       the green component of the color of the rectangle
     * @param blue        the blue component of the color of the rectangle
     * @param startOfLife the time tick at which this rectangle appears
     * @param endOfLife   the time tick at which this rectangle disappears
     * @return this builder with the rectangle added to its list of shapes.
     */
    @Override
    public TweenModelBuilder<AnimatorModel> addRectangle(String name, float lx, float ly,
                                                         float width, float height, float red,
                                                         float green, float blue, int startOfLife,
                                                         int endOfLife) {
      Rectangle r = new Rectangle(name, lx, ly, width, height, startOfLife, endOfLife,
              red, green, blue, new ArrayList<>());
      builderShapes.add(r);
      return this;
    }

    /**
     * This adds a move to the specified shape (indicated by the String name).
     *
     * @param name      the unique name of the shape to be moved
     * @param moveFromX the x-coordinate of the initial position of this shape.
     *                  What this x-coordinate represents depends on the shape.
     * @param moveFromY the y-coordinate of the initial position of this shape.
     *                  what this y-coordinate represents depends on the shape.
     * @param moveToX   the x-coordinate of the final position of this shape. What
     *                  this x-coordinate represents depends on the shape.
     * @param moveToY   the y-coordinate of the final position of this shape. what
     *                  this y-coordinate represents depends on the shape.
     * @param startTime the time tick at which this movement should start
     * @param endTime   the time tick at which this movement should end
     * @return this builder with the move added to the specified shape.
     */
    @Override
    public TweenModelBuilder<AnimatorModel> addMove(String name, float moveFromX,
                                                    float moveFromY, float moveToX, float moveToY,
                                                    int startTime, int endTime) {
      Move m = new Move(name, moveFromX, moveFromY, moveToX, moveToY, startTime, endTime);
      for (IShape s : builderShapes) {
        if (s.getName().equals(name)) {
          s.addCommand(m);
        }
      }
      return this;
    }

    /**
     * This adds a color change to the specified shape (indicated by the String name).
     *
     * @param name      the unique name of the shape whose color is to be changed
     * @param oldR      the r-component of the old color
     * @param oldG      the g-component of the old color
     * @param oldB      the b-component of the old color
     * @param newR      the r-component of the new color
     * @param newG      the g-component of the new color
     * @param newB      the b-component of the new color
     * @param startTime the time tick at which this color change should start
     * @param endTime   the time tick at which this color change should end
     * @return this builder with the color change added to the specified shape.
     */
    @Override
    public TweenModelBuilder<AnimatorModel> addColorChange(String name, float oldR, float oldG,
                                                           float oldB, float newR,
                                                           float newG, float newB, int startTime,
                                                           int endTime) {
      Color c = new Color(name, oldR, oldG, oldB, newR, newG, newB, startTime, endTime);
      for (IShape s : builderShapes) {
        if (s.getName().equals(name)) {
          s.addCommand(c);
        }
      }
      return this;
    }

    /**
     * This adds a scale to the specified shape.
     *
     * @param name      the unique name of the shape whose dimensions is to be changed
     * @param fromSx    the initial x-dimension of this shape.
     *                  What this x-dimension represents depends on the shape.
     * @param fromSy    the initial y-dimension of this shape.
     *                  What this y-dimension represents depends on the shape.
     * @param toSx      the x-dimension of the final position of this shape.
     * @param toSy      the y-dimension of the final position of this shape.
     * @param startTime the time tick at which this scale should start
     * @param endTime   the time tick at which this scale should end.
     * @return this builder with the scale change added to the specified shape.
     */
    @Override
    public TweenModelBuilder<AnimatorModel> addScaleToChange(String name, float fromSx,
                                                             float fromSy, float toSx, float toSy,
                                                             int startTime, int endTime) {
      Scale s = new Scale(name, fromSx, fromSy, toSx, toSy, startTime, endTime);
      for (IShape sh : builderShapes) {
        if (sh.getName().equals(name)) {
          sh.addCommand(s);
        }
      }
      return this;
    }

    /**
     * This builds the model with the builder we just constructed.
     *
     * @return an AnimatorModel with all shapes and transformations added.
     */
    @Override
    public AnimatorModel build() {
      return new AnimatorModelImpl(this);
    }
  }
}
