package cs3500.animator.model;

/**
 * This is the model interface represents the operations that are offered by the IShape model. It
 * includes all of the methods and operations that accessible to the client.
 */
public interface IAnimator {
  /**
   * This checks if the commands passed into the class is actually a MOVESHAPE.
   */
  Enum getCommandType();

  /**
   * This method checks if the given transformation overlaps with the given command.
   *
   * @param c an animation
   * @return the boolean of the overlapped transformation
   */
  boolean overlap(IAnimator c);

  /**
   * This method gets this commands's startTime.
   *
   * @return startTime of the commands.
   */
  double getStartTime();

  /**
   * This method gets this commands's endTime.
   *
   * @return endTime of the commands.
   */
  double getEndTime();

  /**
   * This method will turn the animations into string descriptions.
   *
   * @return a String of the specified animation
   */
  String toString();

  /**
   * This method sets the time field according to the given ticks per second.
   *
   * @param ticksPerSecond the time per second you're setting the tempo to.
   */
  void setTempo(int ticksPerSecond);

  /**
   * This method takes in the type of the shape and returns an SVG command according to what
   * command the shape has.
   *
   * @param type that the shape has.
   * @return the output of the SVG command in a string form.
   */
  String printSVGCommand(String type);

  /**
   * This method applies the animation at the specified shape and frameCount.
   *
   * @param shape      takes in a shape
   * @param frameCount takes in a double frameCount
   */
  void applyAnimationAt(IShape shape, double frameCount);

  /**
   * The method tween takes in the frameCount, startTime, endTime, startVal and endVal of a shape
   * and interpolates the everything accordingly.
   *
   * @param frameCount the frameCount of the shape
   * @param startTime  the startTime of the shape
   * @param endTime    the endTime of the shape
   * @param startVal   the startVal of the shape
   * @param endVal     the endVal of the shape
   * @return the interpolated value of the shape.
   */
  double tween(double frameCount, double startTime, double endTime, double startVal,
               double endVal);
}


