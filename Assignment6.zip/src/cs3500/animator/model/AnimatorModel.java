package cs3500.animator.model;

import java.util.List;

/**
 * This is the interface for the AnimatorModel.
 */
public interface AnimatorModel {

  /**
   * This function gets the state of the frame at a specific time.
   *
   * @return a list representing the list of shapes at the given frame.
   */
  List<IShape> getShapesAtFrame(double time);

  /**
   * This function essentially gets the whole entire description of the user input and spits out a
   * coherent paragraph.
   *
   * @return a text description of the entire animation
   */
  String printAsString();

  /**
   * Changes all time fields according to the given ticksPerSecond.
   */
  void setTempo(int ticksPerSecond);

  /**
   * Looks through the entire list of shapes' disappear times and returns the largest one.
   *
   * @return double representing when the last shape appears
   */
  double getMaxDisappearTime();

  /**
   * Prints out a text description of the animation in SVG format.
   *
   * @return a string representing svg-formatted animation
   */
  String printSVGDescription();
}