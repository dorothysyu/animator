package cs3500.animator.model;

/**
 * This class represents a command type that scales a shape accordingly.
 */
public class Scale extends AAnimator {

  private String name;

  private double fromWidth;
  private double fromHeight;

  // The width and height that the user wants to increase or decrease the shape by.
  private double toWidth;
  private double toHeight;

  /**
   * The constructor for the Scale class.
   */
  public Scale(String name, double fromWidth, double fromHeight, double toWidth, double toHeight,
               double startTime, double endTime) {
    super(startTime, endTime);
    if (fromWidth < 0 || fromHeight < 0 || toWidth < 0 || toHeight < 0) {
      throw new IllegalArgumentException("Can't have negative dimensions.");
    }
    this.name = name;
    this.fromWidth = fromWidth;
    this.fromHeight = fromHeight;
    this.toWidth = toWidth;
    this.toHeight = toHeight;
  }

  /**
   * This checks if the commands passed into the class is actually a CHANGESCALE.
   *
   * @return the enum of the commandType
   */
  public CommandType getCommandType() {
    return CommandType.CHANGESCALE;
  }

  /**
   * This method toString returns a string of the shape description of how the shape is being
   * scaled.
   *
   * @return the formatted String of the shape.
   */
  public String toString() {
    return "Shape " + this.name + " scales from Width: " + this.fromWidth + ", Height: "
            + this.fromHeight + " to Width: " + this.toWidth + ", Height: "
            + this.toHeight + " from t=" + this.startTime + "s" + " to t=" + this.endTime + "s";
  }

  /**
   * This method applies the animation at the specific tweened newWidth and newHeight in scale.
   *
   * @param shape      takes in the Shape of the animation
   * @param frameCount the frameCount time in double
   */
  public void applyAnimationAt(IShape shape, double frameCount) {
    double newWidth = tween(frameCount, this.startTime, this.endTime, fromWidth, toWidth);
    double newHeight = tween(frameCount, this.startTime, this.endTime, fromHeight, toHeight);
    shape.setWidth(newWidth);
    shape.setHeight(newHeight);
  }

  /**
   * This method prints out the svg description of the scaled shape.
   *
   * @param type it takes in a type, either oval or rectangle in this case.
   * @return a String formatted svg code.
   */
  public String printSVGCommand(String type) {
    if (type.equals("oval")) {
      return "\t<animate attributeType=\"xml\" begin=\"" + (this.startTime * 1000.0) + "ms\" dur=\""
              +
              ((this.endTime - this.startTime) * 1000.0) + "ms\" attributeName=\"rx\" from=\""
              + this.fromWidth +
              "\" to=\"" + this.toWidth
              + "\" fill=\"freeze\" />\n<animate attributeType=\"xml\" begin=\""
              + this.startTime * 1000.0 + "ms\" dur=\"" + ((this.endTime - this.startTime) * 1000.0)
              + "ms\" "
              + "attributeName=\"ry\" from=\"" + this.fromHeight + "\" to=\"" + this.toHeight
              + "\" fill=\"freeze\" />\n";
    } else {
      return "\t<animate attributeType=\"xml\" begin=\"" + (this.startTime * 1000.0) + "ms\" dur=\""
              +
              ((this.endTime - this.startTime) * 1000.0) + "ms\" attributeName=\"width\" from=\""
              + this.fromWidth +
              "\" to=\"" + this.toWidth
              + "\" fill=\"freeze\" />\n<animate attributeType=\"xml\" begin=\""
              + (this.startTime * 1000.0) + "ms\" dur=\""
              + ((this.endTime - this.startTime) * 1000.0) + "ms\" " + "attributeName=\"height\" " +
              "from=\"" + this.fromHeight + "\" to=\"" + this.toHeight
              + "\" fill=\"freeze\" />\n";
    }
  }
}


