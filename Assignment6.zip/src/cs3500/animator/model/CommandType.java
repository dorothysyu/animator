package cs3500.animator.model;

/**
 * The enum that checks for which commandType of the animation the user wants. MOVESHAPE moves the
 * shape, CHANGECOLOR changes the color, and CHANGESCALE changes the scale of the shapes.
 */
public enum CommandType {
  MOVESHAPE, CHANGECOLOR, CHANGESCALE;
}


