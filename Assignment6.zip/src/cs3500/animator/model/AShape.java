package cs3500.animator.model;

import java.util.List;

/**
 * AShape is an abstract shape class.
 */
public abstract class AShape implements IShape {

  // IShape takes in a list of commands.
  public List<IAnimator> commands;
  // The name of the shape
  protected String name;
  // The type of shape this shape is.
  protected String type;
  // The XY position of the shape
  protected double positionX;
  protected double positionY;
  // The dimensions of the shape
  protected double width;
  protected double height;
  // when the shape appears and disappear, for example from t=1 to t=5
  protected double appearAt;
  protected double disappearAt;
  // the color of the shape
  protected double colorR;
  protected double colorG;
  protected double colorB;

  /**
   * The constructor for the shape class.
   */
  public AShape(String name, double positionX, double positionY, double width,
                double height, double appearAt, double disappearAt, double colorR,
                double colorG, double colorB, List<IAnimator> commands) {
    if (width < 0 || height < 0 || appearAt < 0 || colorR < 0 || colorG < 0 || colorB < 0
            || colorR > 1 || colorG > 1 || colorB > 1) {
      throw new IllegalArgumentException("Make sure you have positive arguments where they " +
              "need to be");
    }
    if (appearAt > disappearAt) {
      throw new IllegalArgumentException("Please add valid shape lifespan.");
    }
    this.name = name;
    this.type = getType();
    this.positionX = positionX;
    this.positionY = positionY;
    this.width = width;
    this.height = height;
    this.appearAt = appearAt;
    this.disappearAt = disappearAt;
    this.colorR = colorR;
    this.colorG = colorG;
    this.colorB = colorB;
    this.commands = commands;
  }

  /**
   * This creates a deep copy of the given shape.
   *
   * @param shape the shape to be copied
   */

  public AShape(IShape shape) {
    this.name = shape.getName();
    this.type = shape.getType();
    this.positionX = shape.getPositionX();
    this.positionY = shape.getPositionY();
    this.width = shape.getWidth();
    this.height = shape.getHeight();
    this.appearAt = shape.getAppearAt();
    this.disappearAt = shape.getDisappearAt();
    this.colorR = shape.getColorR();
    this.colorG = shape.getColorG();
    this.colorB = shape.getColorB();
    this.commands = shape.getCommands();
  }

  /**
   * This function adds the given transformation to this shape's list of commands.
   * This will throw an exception if the given command conflicts with any of this shape's
   * already existing commands.
   */
  public void addCommand(IAnimator c) throws IllegalArgumentException {
    // accounts for overlapping animations
    for (IAnimator com : commands) {
      if (com.overlap(c)) {
        throw new IllegalArgumentException("Can't add conflicting animations!");
      }
    }
    commands.add(c);
  }

  /**
   * The method getName gets the name of the shape.
   *
   * @return the name of the shape
   */
  public String getName() {
    return this.name;
  }

  /**
   * The method getType returns the type of the shape.
   *
   * @return the name of the type
   */
  public abstract String getType();

  /**
   * The method getPositionX gets the position of the current shape you're at.
   *
   * @return the x position of a shape.
   */
  public double getPositionX() {
    return this.positionX;
  }

  /**
   * The method getPositionY gets the position of the current shape you're at.
   *
   * @return the y position of a shape.
   */
  public double getPositionY() {
    return this.positionY;
  }

  /**
   * Gets this shape's width.
   */
  public double getWidth() {
    return this.width;
  }

  /**
   * Sets this shape's width to the given width.
   */
  public void setWidth(double sWidth) {
    this.width = sWidth;
  }

  /**
   * Gets this shape's height.
   */
  public double getHeight() {
    return this.height;
  }

  /**
   * Sets this shape's height to the given height.
   */
  public void setHeight(double sHeight) {
    this.height = sHeight;
  }

  /**
   * The method getAppearAt gets the starting time of the current shape you're at.
   *
   * @return the starting time
   */
  public double getAppearAt() {
    return this.appearAt;
  }

  /**
   * The method getDisappearAt gets the end time of the current shape you're at.
   *
   * @return the end time
   */
  public double getDisappearAt() {
    return this.disappearAt;
  }

  /**
   * Gets this shape's commands.
   */
  public List<IAnimator> getCommands() {
    return commands;
  }

  /**
   * The method setPositionX sets the position of the shape the user enters.
   *
   * @return the x position of the shape the user sets.
   */
  public double setPositionX(double posX) {
    this.positionX = posX;
    return posX;
  }

  /**
   * The method setPositionY sets the position of the shape that the user sets it.
   *
   * @return the y position the user sets.
   */
  public double setPositionY(double posY) {
    this.positionY = posY;
    return posY;
  }

  /**
   * Gets the r-component of this shape's RGB color.
   */
  public double getColorR() {
    return this.colorR;
  }

  /**
   * Sets the r-component to the given double.
   */
  public void setColorR(double sColorR) {
    this.colorR = sColorR;
  }

  /**
   * Gets the G-component of this shape's RGB color.
   */
  public double getColorG() {
    return this.colorG;
  }

  /**
   * Sets the G-component to the given double.
   */
  public void setColorG(double sColorG) {
    this.colorG = sColorG;
  }

  /**
   * Gets the r-component of this shape's RGB color.
   */
  public double getColorB() {
    return this.colorB;
  }

  /**
   * Sets the B-component to the given double.
   */
  public void setColorB(double sColorB) {
    this.colorB = sColorB;
  }

  /**
   * Turns the commands into strings.
   *
   * @return str
   */
  public String commandsToStrings() {
    String str = "";
    for (IAnimator com : commands) {
      str += com.toString() + "\n";
    }
    return str;
  }

  /**
   * Creates a deep copy of the given shape.
   *
   * @param myShape the shape to be copied.
   * @return a new shape that is identical to the given shape.
   */
  public abstract IShape copyShape(IShape myShape);

  /**
   * Returns a text description of this shape's fields, without the list of commands.
   */
  public abstract String printShapeDescription();

  /**
   * Modifies this shape's time fields according to the given ticksPerSecond, and also sets
   * each command's time fields.
   */
  public void setTempo(int ticksPerSecond) {
    this.appearAt = appearAt / ticksPerSecond;
    this.disappearAt = disappearAt / ticksPerSecond;
    for (IAnimator a : commands) {
      a.setTempo(ticksPerSecond);
    }
  }

  /**
   * Returns a shape that represents this shape's state at the given time.
   *
   * @param frameCount the time that at which the states would be caculated.
   */
  public IShape getStateAt(double frameCount) {
    IShape shapeAtFrame = copyShape(this);
    for (IAnimator a : commands) {
      // if the frame is within the command's active window, then
      // apply the animation at that time
      if (frameCount <= a.getEndTime() && frameCount >= a.getStartTime()) {
        a.applyAnimationAt(shapeAtFrame, frameCount);
      }
      // if the frame is greater than the command's time window (i.e. the attribute of this shape
      // is not changing at that time, then apply the animation at the previous state.
      else if (frameCount >= a.getEndTime()) {
        a.applyAnimationAt(shapeAtFrame, a.getEndTime());
      }
    }
    return shapeAtFrame;
  }

  /**
   * Returns a text description of the shape's starting state in SVG format.
   */
  public abstract String printSVGDescription();

  /**
   * Return a text description of this shape's transformations in SVG format.
   */
  public String printSVGCommands() {
    String output = "";
    for (IAnimator a : this.getCommands()) {
      output += a.printSVGCommand(type);
    }
    return output;
  }

  /**
   * Returns a text description of this entire shape in SVG format
   * (with fields and commands included).
   */
  public abstract String printSVGShape();

  /**
   * Returns an SVG tag that makes this shape visible only at this shape's life
   * (start time to end time).
   */
  public String makeVisible() {
    return "<set attributeName=\"visibility\" attributeType=\"xml\""
            + " to=\"visible\" begin=\"" + this.getAppearAt() + "s\" dur=\"" +
            (this.getDisappearAt() - this.getAppearAt() * 1000) + "s\" fill=\"freeze\"/>";
  }


  /**
   * The enum that checks for which commandType of the animation the user wants. MOVESHAPE moves the
   * shape, CHANGECOLOR changes the color, and CHANGESCALE changes the scale of the shapes.
   */
  enum CommandType {
    MOVESHAPE, CHANGECOLOR, CHANGESCALE;
  }


}
