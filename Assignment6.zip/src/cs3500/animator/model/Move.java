package cs3500.animator.model;

/**
 * The move class takes in the position of the shape and moves it to a certain distance.
 */
public class Move extends AAnimator {

  // Where you're moving the shape from
  private double fromX;
  private double fromY;

  // Where you're moving the shape to
  private double toX;
  private double toY;

  // The name of the shape.
  private String name;

  /**
   * The constructor for move.
   */
  public Move(String name, double fromX, double fromY, double toX, double toY,
              double startTime, double endTime) {
    super(startTime, endTime);
    if (fromX < 0 || fromY < 0 || toX < 0 || toY < 0) {
      throw new IllegalArgumentException("Can't have negative dimensions.");
    }
    this.name = name;
    this.fromX = fromX;
    this.fromY = fromY;
    this.toX = toX;
    this.toY = toY;
  }

  /**
   * This checks if the commands passed into the class is actually a MOVESHAPE.
   */
  public CommandType getCommandType() {
    return CommandType.MOVESHAPE;
  }

  /**
   * This method toString returns a string of the shape description of how the shape is being
   * moved.
   *
   * @return the formatted String of the shape.
   */
  public String toString() {
    return "Shape " + this.name + " moves from (" + this.fromX + ", "
            + this.fromY + ") to ("
            + this.toX + ", "
            + this.toY + ") from t=" + this.startTime + "s" + " to t=" + this.endTime + "s";
  }

  /**
   * This method applies the animation at the specific tweened newX and newY in move.
   *
   * @param shape      takes in the Shape of the animation
   * @param frameCount the frameCount time in double
   */
  public void applyAnimationAt(IShape shape, double frameCount) {
    double newX = tween(frameCount, startTime, endTime, fromX, toX);
    double newY = tween(frameCount, startTime, endTime, fromY, toY);
    shape.setPositionX(newX);
    shape.setPositionY(newY);
  }

  /**
   * This method prints out the move command in a string form for when you're constructing the view
   * in SVG form.
   *
   * @param type takes in a type of the shape, could be either "rectangle" or oval
   * @return the formatted SVG command in a String form.
   */
  public String printSVGCommand(String type) {
    if (type.equals("oval")) {
      return "\t<animate attributeType=\"xml\" begin=\"" + (this.startTime * 1000.0) + "ms\" dur=\""
              +
              ((this.endTime - this.startTime) * 1000.0) + "ms\" attributeName=\"cx\" from=\""
              + this.fromX +
              "\" to=\"" + this.toX + "\" fill=\"freeze\" />\n<animate attributeType=\"xml\" " +
              "begin=\"" + (this.startTime * 1000.0) + "ms\" dur=\""
              + ((this.endTime - this.startTime) * 1000.0) + "ms\""
              + " attributeName=\"cy\" from=\"" + this.fromY + "\" to=\"" + this.toY
              + "\" fill=\"freeze\" />";
    } else {
      return "\t<animate attributeType=\"xml\" begin=\"" + (this.startTime * 1000.0) + "ms\" dur=\""
              +
              ((this.endTime - this.startTime) * 1000.0) + "ms\" attributeName=\"x\" from=\""
              + this.fromX +
              "\" to=\"" + this.toX + "\" fill=\"freeze\" />\n<animate attributeType=\"xml\" " +
              "begin=\"" +
              (this.startTime * 1000.0) + "ms\" dur=\"" + ((this.endTime - this.startTime) * 1000.0)
              + "ms\""
              + " attributeName=\"y\" from=\"" + this.fromY + "\" to=\"" + this.toY
              + "\" fill=\"freeze\" />";
    }
  }
}


