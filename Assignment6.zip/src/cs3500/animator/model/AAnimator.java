package cs3500.animator.model;

/**
 * The class AAnimator contains the method animate so it would double dispatch it to the color, move
 * and scale class according to what the user wants to animate.
 */
abstract public class AAnimator implements IAnimator {

  protected double startTime;
  protected double endTime;
  protected CommandType comType;

  /**
   * The constructor for the AAnimator class that takes in a shape, startTime and endTime.
   */
  protected AAnimator(double startTime, double endTime) {
    if (startTime < 0 || endTime < 0) {
      throw new IllegalArgumentException("Time can't be negative >:(");
    }
    this.startTime = startTime;
    this.endTime = endTime;
    this.comType = getCommandType();
  }

  /**
   * This checks if this animation conflicts with the given animation. An animation conflicts
   * this and the given are the same animation and their time intervals overlap.
   *
   * @param c the animation that this is compared
   * @return boolean representing if this overlaps with the given animation.
   */
  public boolean overlap(IAnimator c) {
    return ((this.comType == c.getCommandType())
            && ((this.endTime >= c.getStartTime()) && (c.getEndTime() >= this.startTime)));
  }

  /**
   * Gets this animation's start time.
   *
   * @return this start time.
   */
  @Override
  public double getStartTime() {
    return startTime;
  }

  /**
   * Gets this animation's end time.
   *
   * @return this end time.
   */
  @Override
  public double getEndTime() {
    return endTime;
  }

  /**
   * An abstract method that declares that its child classes will be able to get
   * this animation's animation type.
   *
   * @return this command type.
   */
  abstract public CommandType getCommandType();

  /**
   * This sets the shape's fields to its respective values after the animation has been applied
   * at the given frame count.
   *
   * @param shape      the shape to which the animation will be applied
   * @param frameCount the frame count that the values will be calculated according to.
   */
  public abstract void applyAnimationAt(IShape shape, double frameCount);

  /**
   * Sets this time fields according to the given ticksPerSecond.
   *
   * @param ticksPerSecond the tempo of the animation
   */
  public void setTempo(int ticksPerSecond) {
    this.startTime = startTime / ticksPerSecond;
    this.endTime = endTime / ticksPerSecond;
  }

  /**
   * Linearly interpolates the value at the given frameCount based on the start value, end value,
   * start time, and end time of this animation.
   *
   * @param frameCount the frame at which the given value is calculated
   * @param startTime  the start time of this animation
   * @param endTime    the end time of this animation
   * @param startVal   the start value of this animation
   * @param endVal     the end value of this animation
   * @return a double representing the value at the given frameCount
   */
  public double tween(double frameCount, double startTime, double endTime, double startVal,
                      double endVal) {
    if ((frameCount > this.endTime) || (frameCount < this.startTime)) {
      frameCount = this.endTime;
    }
    return ((startVal * (endTime - frameCount) / (endTime - startTime)) +
            (endVal * (frameCount - startTime) / (endTime - startTime)));
  }

}