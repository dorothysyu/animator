package cs3500.animator.model;

import java.util.List;

/**
 * This is the model interface represents the operations that are offered by the IShape model. It
 * includes all of the methods and operations that accessible to the client.
 */
public interface IShape {

  /**
   * This function adds a commands according to what commands the user types in.
   */
  void addCommand(IAnimator c);

  /**
   * This method gets all of the commands that are in a shape and returns a list of them.
   *
   * @return a list of commands that the shape has.
   */
  List<IAnimator> getCommands();

  /**
   * This method will print out all of the SVG commands in a string form.
   *
   * @return the formatted string of the SVG commands.
   */
  String printSVGCommands();

  /**
   * The method getName gets the name of the shape.
   *
   * @return the name of the shape
   */
  String getName();

  /**
   * The method getType returns the type of the shape.
   *
   * @return the name of the type
   */
  String getType();

  /**
   * Prints the shape's description.
   */
  String printShapeDescription();

  /**
   * This method prints out the SVG description of a specific shape in a String form.
   *
   * @return a String form of the SVG Description/
   */
  String printSVGDescription();

  /**
   * The method getPositionX gets the position of the current shape you're at.
   *
   * @return the x position of a shape.
   */
  double getPositionX();

  /**
   * The method setPositionX sets the position of the shape the user enters.
   *
   * @return the x position of the shape the user sets.
   */
  double setPositionX(double posx);

  /**
   * The method getPositionY gets the position of the current shape you're at.
   *
   * @return the y position of a shape.
   */
  double getPositionY();

  /**
   * The method setPositionY sets the position of the shape that the user sets it.
   *
   * @return the y position the user sets.
   */
  double setPositionY(double posy);

  /**
   * The method gets the width of the shape.
   *
   * @return width of the shape
   */
  double getWidth();

  /**
   * The method sWidth sets the width of the shape.
   *
   * @param sWidth the width of the shape.
   */
  void setWidth(double sWidth);

  /**
   * The method gets the height of the shape.
   *
   * @return height of the shape
   */
  double getHeight();

  /**
   * The method sHeight sets the height of the shape.
   *
   * @param sHeight the height of the shape
   */
  void setHeight(double sHeight);

  /**
   * The method getAppearAt gets the starting time of the current shape you're at.
   *
   * @return the starting time
   */
  double getAppearAt();

  /**
   * The method getDisappearAt gets the end time of the current shape you're at.
   *
   * @return the end time
   */
  double getDisappearAt();

  /**
   * The method getColorR gets the R value of the color.
   *
   * @return the R value of the color
   */
  double getColorR();

  /**
   * The method sColorR sets the R value of the color.
   *
   * @param sColorR the R value of the color.
   */
  void setColorR(double sColorR);

  /**
   * The method getColorG gets the G value of the color.
   *
   * @return the G value of the color
   */
  double getColorG();

  /**
   * The method sColorG sets the G value of the color.
   *
   * @param sColorG the G value of the color.
   */
  void setColorG(double sColorG);

  /**
   * The method getColorB gets the B value of the color.
   *
   * @return the B value of the color
   */
  double getColorB();

  /**
   * The method sColorB sets the B value of the color.
   *
   * @param sColorB the B value of the color
   */
  void setColorB(double sColorB);

  /**
   * Turns the commands into strings.
   *
   * @return commands in string form
   */
  String commandsToStrings();

  /**
   * Sets the tempo of each shape.
   */
  void setTempo(int ticksPerSecond);

  /**
   * The method getStateAt takes in a frameCount (a specific time) and returns a shape at the
   * specified state.
   *
   * @param frameCount the specified time in double.
   * @return the shape at the specified state.
   */
  IShape getStateAt(double frameCount);

  /**
   * This method prints out the svg description of the shape in a string form.
   *
   * @return the SVG description of a shape in a String
   */
  String printSVGShape();
}


