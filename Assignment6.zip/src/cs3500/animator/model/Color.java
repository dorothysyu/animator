package cs3500.animator.model;

/**
 * This is the color class that controls the changes in color of a shape.
 */
public class Color extends AAnimator {

  // The name of the shape
  private String name;

  // The from values of the RGB
  private double fromColorR;
  private double fromColorG;
  private double fromColorB;

  // The to values of the RGB
  private double toColorR;
  private double toColorG;
  private double toColorB;

  /**
   * The constructor for the Color class.
   */
  public Color(String name, double fromColorR, double fromColorG, double fromColorB,
               double toColorR, double toColorG, double toColorB, double startTime,
               double endTime) {
    super(startTime, endTime);
    if (fromColorB < 0 || fromColorG < 0 || fromColorB < 0 || toColorR < 0 || toColorG < 0
            || toColorB < 0 || fromColorB > 1 || fromColorG > 1 || fromColorB > 1 || toColorR > 1
            || toColorG > 1 || toColorB > 1) {
      throw new IllegalArgumentException("Can't have negative color components.");
    }
    this.name = name;
    this.fromColorR = fromColorR;
    this.fromColorG = fromColorG;
    this.fromColorB = fromColorB;
    this.toColorR = toColorR;
    this.toColorG = toColorG;
    this.toColorB = toColorB;
  }

  /**
   * This checks if the commands passed into the class is actually a CHANGECOLOR.
   *
   * @return the commandType of the method
   */
  public CommandType getCommandType() {
    return CommandType.CHANGECOLOR;
  }

  /**
   * This method toString returns a string of the shape description of how the color of the shape is
   * being changed.
   *
   * @return the formatted String of the shape.
   */
  public String toString() {
    return "Shape " + this.name + " changes color from (" + this.fromColorR + ", "
            + this.fromColorG + ", " + this.fromColorB + ") to (" + this.toColorR + ", " +
            this.toColorG + ", " + this.toColorB + ") from t=" + this.startTime + "s" +
            " to t=" + this.endTime + "s";
  }

  /**
   * This method applies the animation at the specific tweened newR, newG and newB in Color.
   *
   * @param shape      takes in the Shape of the animation
   * @param frameCount the frameCount time in double
   */
  public void applyAnimationAt(IShape shape, double frameCount) {
    double newR = tween(frameCount, startTime, endTime, fromColorR, toColorR);
    double newG = tween(frameCount, startTime, endTime, fromColorG, toColorG);
    double newB = tween(frameCount, startTime, endTime, fromColorB, toColorB);
    shape.setColorR(newR);
    shape.setColorG(newG);
    shape.setColorB(newB);
  }

  /**
   * This method prints out the color command in a string form for when you're constructing the view
   * in SVG form.
   *
   * @param type takes in a type of the shape, could be either "rectangle" or oval
   * @return the formatted SVG command in a String form.
   */
  public String printSVGCommand(String type) {
    return "\t<animate attributeType=\"xml\" begin=\"" + (this.startTime * 1000.0) + "ms\" dur=\""
            + ((this.endTime - this.startTime) * 1000.0) + "ms\" attributeName=\"fill\" from=\"rgb("
            + (this.fromColorR * 255) + "," + (this.fromColorG * 255) + ","
            + (this.fromColorB * 255)
            + ")" + "\" to=\"rgb(" + (this.toColorR * 255) + "," + (this.toColorG * 255) + ","
            + (this.toColorB * 255) + ")" + "\" fill=\"freeze\" />\n";
  }
}


