package cs3500.animator.model;

import java.util.ArrayList;

/**
 * The Rectangle class is a shape that extends AShape.
 */
public class Rectangle extends AShape {

  /**
   * The constructor for the Rectangle class.
   */
  public Rectangle(String name, double positionX, double positionY, double width, double height,
                   double appearAt, double disappearAt, double colorR, double colorG, double colorB,
                   ArrayList<IAnimator> command) {
    super(name, positionX, positionY, width, height, appearAt, disappearAt, colorR, colorG, colorB,
            command);
  }

  /**
   * A second constructor for Rectangle.
   *
   * @param rect takes in a Rectangle.
   */
  public Rectangle(Rectangle rect) {
    super(rect);
  }

  /**
   * This method gets the type of the shape.
   *
   * @return a String "rectangle" to identify that the type is a rectangle.
   */
  @Override
  public String getType() {
    return "Rectangle";
  }

  /**
   * This method prints out the shape description for a rectangle.
   *
   * @return the String of the shape description.
   */
  public String printShapeDescription() {
    return "Name: " + this.getName() + "\n" + "Type: " + this.getType() + "\n" +
            "Corner: (" + this.getPositionX() + ", " + this.getPositionY() + "), Width: " +
            this.width + ", Height: " + this.height + ", Color: (" + this.getColorR() + ", " +
            this.getColorG() + ", " + this.getColorB() + ")\n" + "Appears at t="
            + this.getAppearAt() + "s" + "\nDisappears at t=" + this.getDisappearAt() + "s\n";
  }

  /**
   * This method is used to copy the current shape and return a new IShape of the current shape
   * you're at.
   *
   * @param myShape takes in an IShape
   * @return an IShape that's the current shape you're at.
   */
  public IShape copyShape(IShape myShape) {
    if (myShape instanceof Rectangle) {
      return new Rectangle((Rectangle) myShape);
    } else {
      throw new IllegalArgumentException("Your shape is not a rectangle!");
    }
  }

  /**
   * This method prints out the svg description of the current shape you're at.
   *
   * @return a String of the svg description.
   */
  public String printSVGDescription() {
    return "<rect id=\"" + this.getName() + "\" x=\"" + this.getPositionX() + "\" y=\""
            + this.getPositionY() + "\" width=\"" + this.getWidth() + "\" height=\""
            + this.getHeight() + " \" fill=\"rgb(" + (this.getColorR() * 255) + ","
            + (this.getColorG() * 255) + "," + (this.getColorB() * 255)
            + ")\" visibility=\"hidden\" >";
  }

  /**
   * This method helps print out all of the description in the SVG description as well as the
   * visibility and commands of the current shape.
   *
   * @return a String format of the description, visibility and commands of SVG.
   */
  public String printSVGShape() {
    return printSVGDescription() + "\n" + this.makeVisible() + this.printSVGCommands() + "</rect>";
  }
}


