package cs3500.animator.model;

import java.util.ArrayList;

/**
 * The Oval class is just an example of how a shape would look like in this implementation.
 */
public class Oval extends AShape {

  /**
   * The constructor for the oval class.
   */
  public Oval(String name, double positionX, double positionY, double width,
              double height, double appearAt, double disappearAt, double colorR, double colorG,
              double colorB, ArrayList<IAnimator> command) {
    super(name, positionX, positionY, width, height, appearAt, disappearAt, colorR, colorG,
            colorB, command);
  }

  /**
   * A second constructor for Oval.
   *
   * @param ov takes in an oval.
   */
  public Oval(Oval ov) {
    super(ov);
  }

  /**
   * This method gets the type of the shape. In this class, it should return oval.
   *
   * @return the type of the shape you're currently at.
   */
  @Override
  public String getType() {
    return "oval";
  }

  /**
   * This method is used to copy the current shape and return a new IShape of the current shape
   * you're at.
   *
   * @param myShape takes in an IShape
   * @return an IShape that's the current shape you're at.
   */
  @Override
  public IShape copyShape(IShape myShape) {
    if (myShape instanceof Oval) {
      return new Oval((Oval) myShape);
    } else {
      throw new IllegalArgumentException("Your shape is not an oval!");
    }
  }

  /**
   * This method prints out the shape description for a rectangle.
   *
   * @return the String of the shape description.
   */
  public String printShapeDescription() {
    return "Name: " + this.getName() + "\n" + "Type: " + this.getType() + "\n" +
            "Center: (" + this.getPositionX() + ", " + this.getPositionY() + "), X radius: " +
            this.width + ", Y radius: " + this.height + ", Color: (" + this.getColorR() + ", " +
            this.getColorG() + ", " + this.getColorB() + ")\n" + "Appears at t="
            + this.getAppearAt() + "s" + "\nDisappears at t=" + this.getDisappearAt() + "s\n";
  }

  /**
   * This method prints out the svg description of the current shape you're at.
   *
   * @return a String of the svg description.
   */
  public String printSVGDescription() {
    return "<ellipse id=\"" + this.getName() + "\" cx=\"" + this.getPositionX() + "\" cy=\""
            + this.getPositionY() + "\" rx=\"" + this.getWidth() + "\" ry=\""
            + this.getHeight() + " \" fill=\"rgb(" + this.getColorR() * 255 + ","
            + this.getColorG() * 255 + "," + this.getColorB() * 255
            + ")\" visibility=\"hidden\" >";
  }

  /**
   * This method helps print out all of the description in the SVG description as well as the
   * visibility and commands of the current shape.
   *
   * @return a String format of the description, visibility and commands of SVG.
   */
  public String printSVGShape() {
    return printSVGDescription() + "\n" + this.makeVisible()
            + this.printSVGCommands() + "</ellipse>";
  }
}


